package com.mygdx.game.EntityManagement;

public interface MovableEntities {
    void move();
}
